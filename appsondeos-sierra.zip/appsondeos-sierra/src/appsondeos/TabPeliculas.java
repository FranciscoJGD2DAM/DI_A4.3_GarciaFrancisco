/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appsondeos;



import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;



public class TabPeliculas extends VBox{
  
   
    private final ToggleGroup selecionCat;
    private final TextField text1;
    private final ChoiceBox año;
    private final ChoiceBox tipo;
    private final ChoiceBox countPeli;
    private final CheckBox selecionar;
    private final Slider slider1;  
    private final Slider slider2;
    private final Slider slider3;
    
    public TabPeliculas()
    {
        GridPane root = new GridPane();
        

        HBox conten1 = new HBox();
        conten1.setPrefWidth(400);
        
        HBox conten2 = new HBox();
        conten1.setAlignment(Pos.CENTER);
        conten2.setAlignment(Pos.CENTER);
        
        HBox conten3 = new HBox();
        conten3.setAlignment(Pos.CENTER);
        
        HBox conten4 = new HBox();
        conten4.setAlignment(Pos.CENTER);
        
        HBox conten5 = new HBox();
        conten5.setAlignment(Pos.CENTER);
        
        HBox conten6 = new HBox();
        conten6.setAlignment(Pos.CENTER);
        
        HBox conten7 = new HBox();
        conten7.setAlignment(Pos.CENTER_RIGHT);
        
        VBox seccion3Peliculas = new VBox();
        
        root.setGridLinesVisible(false);
        
        root.setAlignment(Pos.CENTER);
        root.setHgap(20);
        root.setVgap(20);
        
        root.setPadding(new Insets(30));
        
    
        
        Label label1 = new Label("Nombre: ");
        text1 = new TextField();
        
        
        
        //root1.getChildren().addAll(label1,text1);
        //root.add(label1, 0, 0);
        //root.add(text1, 1 ,0);
        
        Label label2 = new Label("Año de Pelicula: ");
        
        año = new ChoiceBox();
        año.getItems().addAll("1985-1990","1990-1995","1995-2000","2000-2005","2005-2010","2010-2015","2015-2020");
        
        
        Label label3 = new Label("Tipo de pelicula: ");
    
        tipo = new ChoiceBox();
        tipo.getItems().addAll("Comedia","Terror","Aventuras","Musicales","Dramaticas","Ciencia Ficcion","Guerra");
        
        //root2.getChildren().addAll(label2,año,label3,tipo);
        root.add(label1, 0, 0);
        root.add(text1, 1 ,0);
        root.add(label2, 0, 1);
        root.add(año, 1 ,1);
        root.add(label3, 2, 1);
        root.add(tipo, 3 ,1);
        
      
        
        RadioButton mayor3 = new RadioButton("+3");
        mayor3.setSelected(true);
        
        RadioButton mayor7 = new RadioButton("+7");
        RadioButton mayor12 = new RadioButton("+12");
        RadioButton mayor16 = new RadioButton("+16");
        RadioButton mayor18 = new RadioButton("+18");
        
        mayor3.getStyleClass().add("RadioButtons");
        mayor7.getStyleClass().add("RadioButtons");
        mayor12.getStyleClass().add("RadioButtons");
        mayor16.getStyleClass().add("RadioButtons");
        mayor18.getStyleClass().add("RadioButtons");
        
        selecionCat = new ToggleGroup();
        
        mayor3.setToggleGroup(selecionCat);
        mayor7.setToggleGroup(selecionCat);
        mayor12.setToggleGroup(selecionCat);
        mayor16.setToggleGroup(selecionCat);
        mayor18.setToggleGroup(selecionCat);
        
        
        Label selecImagen = new Label();
        
        selecionCat.selectedToggleProperty().addListener( e -> {
            
        if(mayor3.isSelected()){
            Image imagen = new Image("/resources/images/Calificacion3.PNG",50,40,true,false);

            selecImagen.setGraphic(new ImageView(imagen));
        
        }else if (mayor7.isSelected()){
            
            Image imagen = new Image("/resources/images/Calificacion7.PNG",50,40,true,false);
        
            selecImagen.setGraphic(new ImageView(imagen));
        }else if (mayor12.isSelected()){
            
            Image imagen = new Image("/resources/images/Calificacion12.PNG",50,40,true,false);
        
            selecImagen.setGraphic(new ImageView(imagen));
        } else if (mayor16.isSelected()){
            
            Image imagen = new Image("/resources/images/Calificacion16.PNG",50,40,true,false);
        
            selecImagen.setGraphic(new ImageView(imagen));
        }else if (mayor18.isSelected()){
            
            Image imagen = new Image("/resources/images/Calificacion18.PNG",50,40,true,false);
        
            selecImagen.setGraphic(new ImageView(imagen));
        }
        
            
        });
        Image imagen = new Image("/resources/images/Calificacion3.PNG",50,40,true,false);

        selecImagen.setGraphic(new ImageView(imagen));
       
        
        
        
        
        conten1.getChildren().addAll(mayor3,mayor7,mayor12,mayor16,mayor18,selecImagen);
        conten1.setSpacing(50);
        
        
        
        Separator separador1 = new Separator();
        separador1.setPadding(new Insets(20, 10, 10, 10));
        
        selecionar = new CheckBox("¿Ves Peliculas?");
        selecionar.setPadding(new Insets(20, 10, 80, 40));
        
        Label label4 = new Label("Cuantas peliculas ves al mes: ");
        
        countPeli = new ChoiceBox();
        countPeli.getItems().addAll("1-3","3-5","5-7","7-9","9-13","13-mas");
        
        conten2.getChildren().addAll(label4,countPeli);
        conten2.setSpacing(50);
        
        Separator separador2 = new Separator();
        separador2.setPadding(new Insets(40, 10, 0, 10));
        
        Label label5 = new Label("Marque del 1 al 10 la valoracion de la pelicula:");
        //label5.setAlignment(Pos.CENTER);
        conten3.getChildren().add(label5);
        conten3.setPadding(new Insets(40, 0, 20, 0));
        
        
        Label label6 = new Label("Historia: ");
        
        slider1 = new Slider(0, 10, 0);
        slider1.setShowTickMarks(true);
        slider1.setShowTickLabels(true);
        slider1.setMajorTickUnit(1f);
        slider1.setBlockIncrement(0.1f);
        
        slider1.setPrefWidth(250);
       
        
        Label numeroCam = new Label("0");
        
        label6.setPadding(new Insets(0, 30, 15, 0));
        numeroCam.setPadding(new Insets(0, 30, 15, 40));
        
        slider1.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider1.setValue(valor);
            numeroCam.setText(String.valueOf(valor)+ "\n");
        });
        
        
        
        conten4.getChildren().addAll(label6,slider1,numeroCam);
        
        
        conten4.setPadding(new Insets(20, 10, 20, 10));
        
        
        Label label7 = new Label("Escena: ");
        
        slider2 = new Slider(0, 10, 0);
        slider2.setShowTickMarks(true);
        slider2.setShowTickLabels(true);
        slider2.setMajorTickUnit(1f);
        slider2.setBlockIncrement(1.0f);
        
        slider2.setPrefWidth(250);
        
        Label numeroCam2 = new Label("0");
        
        label7.setPadding(new Insets(0, 30, 15, 0));
        numeroCam2.setPadding(new Insets(0, 30, 15, 40)); 
        
        slider2.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider2.setValue(valor);
            numeroCam2.setText(String.valueOf(valor)+ "\n");
        });
    
        conten5.getChildren().addAll(label7,slider2,numeroCam2);
        
        conten5.setPadding(new Insets(20, 10, 20, 10));
        
        Label label8 = new Label("Banda sonora: ");
        
        slider3 = new Slider(0, 10, 0);
        slider3.setShowTickMarks(true);
        slider3.setShowTickLabels(true);
        slider3.setMajorTickUnit(1f);
        slider3.setBlockIncrement(0.1f);
        
        slider3.setPrefWidth(250);
        
        Label numeroCam3 = new Label("0");
        
        label8.setPadding(new Insets(0, 30, 15, 0));
        numeroCam3.setPadding(new Insets(0, 30, 15, 40));
        
        slider3.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider3.setValue(valor);
            numeroCam3.setText(String.valueOf(valor)+ "\n");
        });
        numeroCam3.getText();
        
        conten6.getChildren().addAll(label8,slider3,numeroCam3);
        
        conten6.setPadding(new Insets(20, 10, 20, 10));
        
        Button enviar = new Button("Enviar");
        
        Text tester  = new Text("");
        
        
        enviar.setOnMouseClicked(e -> {
            FileHandler  filehandler = new FileHandler("TabPeliculas",toString(),tester);
        });
        
        conten7.getChildren().addAll(tester,enviar);
        
   
        
        conten7.setPadding(new Insets(10, 40, 20, 10));
        
        seccion3Peliculas.getChildren().addAll(conten3,conten4,conten5,conten6,conten7);
        seccion3Peliculas.getStyleClass().add("seccion3Peliculas");
        seccion3Peliculas.setMinHeight(430.00);
        
        getChildren().addAll(root,conten1,separador1,selecionar,conten2,separador2,seccion3Peliculas);
        //Scene scene = new Scene(root, 600, 425); 
        
    }
      public String getSelectedRadio() 
    {
        RadioButton temporal = (RadioButton)selecionCat.getSelectedToggle();
            return temporal.getText();
    }
      @Override
    public String toString()
    {
        return String.format(text1.getText() + ";" + año.getValue() + ";" + tipo.getValue() + ";" + getSelectedRadio() + ";" + selecionar.isSelected() + ";" + countPeli.getValue() + ";%.2f;%.2f;%.2f;\n",slider1.getValue(),slider2.getValue(),slider3.getValue());
    }
}
