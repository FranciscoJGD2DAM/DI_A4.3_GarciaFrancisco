package appsondeos;

import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;


public class TabMusica extends VBox{
    /*Elementos declarados*/
    
        /*Layouts*/
        private final HBox hbox1;
        private final HBox hbox2;
        private final HBox hbox3;
        private final HBox hbox4;
        private final HBox hbox5;
        private final HBox hbox6;
        private final HBox hbox7;
        private final HBox hbox8;
        private final HBox hbox9;
        private final HBox hbox10;
        private final HBox hbox11;
        private final HBox hbox12;
        private final VBox Layoutprincipal1;
        private final VBox Layoutprincipal2;
        private final VBox Layoutprincipal3;
       
        /*Margenes*/
        private final Insets margen;
        private final Insets labelMargin;
        
        /*Elementos de texto*/
        private final Text texto1;
        private final Text texto2;
        private final Text texto3;
        private final Text texto4;
        private final Text texto5;
        private final Text texto6;
        private final Text texto7;
        private final Text texto8;
        private final Text texto9;
        private final Text texto10;
        private final Text texto11;
        private final Text texto12;
        private final Text texto13;
        private final Text texto14;
        private final TextField textfield1;
        
        /*ChoiceBox*/
        private final ChoiceBox choicebox1;
        private final ChoiceBox choicebox2;
        private final ChoiceBox choicebox3;
        
        /*ToggleGroup*/
        private final ToggleGroup togglegroup1;
        
        /*RadioButtons*/
        private final RadioButton radio1;
        private final RadioButton radio2;
        
        /*CheckBox*/
        private final CheckBox checkbox1;
        
        /*Button*/
        private final Button btn;
        
        /*Separators*/
        private final Separator separador1;
        private final Separator separador2;
        
        /*Slider*/
        private final Slider slider;
        private final Slider slider2;
        private final Slider slider3;
    
    public TabMusica(){
        
        super();
        /*Declara los separadores*/
        separador1 = new Separator();
        separador2 = new Separator();

        /*Boton*/
        btn = new Button("Enviar");
        
        setAlignment(Pos.CENTER);
        margen = new Insets(30,20,20,20);
        labelMargin = new Insets(25,0,20,20);
        
        /*Inicializa los HBox*/
        hbox1 = new HBox();
        hbox2 = new HBox();
        hbox3 = new HBox();
        hbox4 = new HBox();
        hbox5 = new HBox();
        hbox6 = new HBox();
        hbox7 = new HBox();
        hbox8 = new HBox();
        hbox9 = new HBox();
        hbox10 = new HBox();
        hbox11 = new HBox();
        hbox12 = new HBox();
        
        /*Primer separador*/
        texto1 = new Text("Nombre: ");
        textfield1 = new TextField();
        hbox1.getChildren().addAll(texto1, textfield1);
        hbox1.setAlignment(Pos.CENTER);
        HBox.setMargin(texto1,labelMargin);
        HBox.setMargin(textfield1,margen);

        texto2 = new Text("Edad: ");
        texto3 = new Text("Tipo de música favorita: ");
        choicebox1 = new ChoiceBox();
        choicebox1.getItems().addAll("Mayor de 18 años","Entre 18 y 30 años","Entre 30 y 60 años","Mayor de 60 años");
        choicebox1.setValue("---");
        choicebox2 = new ChoiceBox();
        choicebox2.getItems().addAll("Rock", "Pop", "Rap", "Trap", "Clásica", "House", "Tecno", "Reggaeton");
        choicebox2.setValue("---");
        hbox2.getChildren().addAll(texto2,choicebox1,texto3,choicebox2);
        hbox2.setAlignment(Pos.CENTER);
        HBox.setMargin(texto2,labelMargin);
        HBox.setMargin(choicebox1,margen);
        HBox.setMargin(texto3,labelMargin);
        HBox.setMargin(choicebox2,margen);
        
        texto4 = new Text("Sexo: ");
        togglegroup1 = new ToggleGroup();
        radio1 = new RadioButton("Hombre");
        radio1.getStyleClass().add("RadioButtons");
        radio1.setToggleGroup(togglegroup1);
        radio2 = new RadioButton("Mujer");
        radio2.getStyleClass().add("RadioButtons");
        radio2.setToggleGroup(togglegroup1);
        hbox3.getChildren().addAll(texto4,radio1,radio2);
        hbox3.setAlignment(Pos.CENTER);
        HBox.setMargin(texto4,labelMargin);
        HBox.setMargin(radio1,margen);
        HBox.setMargin(radio2,margen);
        
        /*Separador 2*/
        checkbox1 = new CheckBox();
        texto5 = new Text("¿Tienes algún instrumento?");
        hbox4.getChildren().addAll(checkbox1,texto5);
        hbox4.setAlignment(Pos.CENTER);
        HBox.setMargin(checkbox1,labelMargin);
        HBox.setMargin(texto5,margen);
        
        texto6 = new Text("¿Qué tipo de instrumento tienes?: ");
        choicebox3 = new ChoiceBox();
        choicebox3.getItems().addAll("Flauta", "Violin", "Trompeta", "Guitarra electrica", "Bajo electrico", "Oboe", "Clarinete", "Otro");
        hbox5.getChildren().addAll(texto6, choicebox3);
        hbox5.setAlignment(Pos.CENTER);
        HBox.setMargin(texto6,labelMargin);
        HBox.setMargin(choicebox3,margen);
        
        /*Separador 3*/
        texto7 = new Text("Marque del 1 al 1 su grado de aficción a:");
        hbox6.setAlignment(Pos.CENTER);
        texto8 = new Text("Escuchar música alegre: \n");
        texto9 = new Text("Escuchar música relajante: \n");
        texto10 = new Text("Escuchar música triste: \n");
        texto11 = new Text("0.00\n");
        texto12 = new Text("0.00\n");
        texto13 = new Text("0.00\n");
        
        /*Primer slider*/
        slider = new Slider(1, 10, 0.5);
        slider.setShowTickMarks(true);
        slider.setShowTickLabels(true);
        slider.setMajorTickUnit(1f);
        slider.setBlockIncrement(0.1f);
        slider.setPrefWidth(230);
        
        slider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider.setValue(valor);
            texto11.setText(String.valueOf(valor)+ "\n");
        });
        
        /*Segundo slider*/
        slider2 = new Slider(1, 10, 0.5);
        slider2.setShowTickMarks(true);
        slider2.setShowTickLabels(true);
        slider2.setMajorTickUnit(1f);
        slider2.setBlockIncrement(0.1f);
        slider2.setPrefWidth(230);
        
        slider2.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider2.setValue(valor);
            texto12.setText(String.valueOf(valor)+ "\n");
        });
        
        /*Tercer slider*/
        slider3 = new Slider(1, 10, 0.5);
        slider3.setShowTickMarks(true);
        slider3.setShowTickLabels(true);
        slider3.setMajorTickUnit(1f);
        slider3.setBlockIncrement(0.1f);
        slider3.setPrefWidth(230);
        
        slider3.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider3.setValue(valor);
            texto13.setText(String.valueOf(valor)+ "\n");
        });
        
        hbox8.getChildren().add(texto7);
        HBox.setMargin(texto7, labelMargin);
        hbox8.setAlignment(Pos.CENTER);
        
        hbox9.getChildren().addAll(texto8,slider,texto11);
        HBox.setMargin(texto8, labelMargin);
        HBox.setMargin(slider, margen);
        HBox.setMargin(texto11, margen);
        hbox9.setAlignment(Pos.CENTER);
        
        hbox10.getChildren().addAll(texto9,slider2,texto12);
        HBox.setMargin(texto9, labelMargin);
        HBox.setMargin(slider2, margen);
        HBox.setMargin(texto12, margen);
        hbox10.setAlignment(Pos.CENTER);
        
        hbox11.getChildren().addAll(texto10,slider3,texto13);
        HBox.setMargin(texto10, labelMargin);
        HBox.setMargin(slider3, margen);
        HBox.setMargin(texto13, margen);
        hbox11.setAlignment(Pos.CENTER);
        
        hbox12.getChildren().add(btn);
        hbox12.setAlignment(Pos.CENTER_RIGHT);
        hbox12.setMargin(btn, margen);
        
        /*Funcion del botón*/
        texto14 = new Text("Encuesta enviada: \n");
        btn.setOnMouseClicked(e -> {
            FileHandler filehandler = new FileHandler("TabMusica",toString(),texto14);
        });
        
        Layoutprincipal1 = new VBox();
        Layoutprincipal1.getChildren().addAll(hbox1, hbox2, hbox3);
        Layoutprincipal1.getStyleClass().add("Tab_Musica_1");
        
        Layoutprincipal2 = new VBox();
        Layoutprincipal2.getChildren().addAll(hbox4, hbox5);
        Layoutprincipal2.getStyleClass().add("Tab_Musica_2");
        
        Layoutprincipal3 = new VBox();
        Layoutprincipal3.getChildren().addAll(hbox6, hbox7, hbox8, hbox9, hbox10, hbox11, hbox12);
        Layoutprincipal3.getStyleClass().add("Tab_Musica_3");
        
        /*Añade los elementos creados al Tab*/
        this.getChildren().addAll(Layoutprincipal1, separador1, Layoutprincipal2, separador2, Layoutprincipal3);
    }
    
    public String getSelectedRadio()
    {
        RadioButton temporal = (RadioButton)togglegroup1.getSelectedToggle();
        return String.format(temporal.getText());
    }
    
    @Override
    public String toString()
    {
        return String.format(textfield1.getText() + ";" + choicebox1.getValue() + ";" + choicebox2.getValue() + ";" + getSelectedRadio() + ";" + checkbox1.isSelected() + ";" + choicebox3.getValue() + ";%.0f;%.0f;%.0f;\n",slider.getValue(),slider2.getValue(),slider3.getValue());
    }
}
