package appsondeos;

import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class TabLecturas extends VBox
{

    //Separators
    private final Separator separator1;
    private final Separator separator2;
    
    //Margin
    private final Insets margin;
    private final Insets labelMargin;
    
    //Layouts
    private final HBox field1Layout1;
    private final HBox field1Layout2;
    private final HBox field1Layout3;
    private final HBox field2Layout1;
    private final HBox field2Layout2;
    private final HBox field3Layout1;
    private final HBox field3Layout2;
    private final HBox field3Layout3;
    private final HBox field3Layout4;
    private final HBox field3Layout5;
    private final VBox masterLayout1;
    private final VBox masterLayout2;
    private final VBox masterLayout3;

    //Elements
    private final Text text1;
    private final Text text2;
    private final Text text3;
    private final Text text4;
    private final Text text5;
    private final Text text6;
    private final Text text7;
    private final Text text8;
    private final Text text9;
    private final Text text10;
    private final Text text11;
    private final Text text12;
    private final Text text13;
    private final Text text14;
    private final TextField textfield1;
    private final ChoiceBox choicebox1;
    private final ChoiceBox choicebox2;
    private final ChoiceBox choicebox3;
    private final ToggleGroup togglegroup1;
    private final RadioButton radio1;
    private final RadioButton radio2;
    private final RadioButton radio3;
    private final RadioButton radio4;
    private final CheckBox toggle1;
    private final Slider slider1;
    private final Slider slider2;
    private final Slider slider3;
    private final Button submit;
    
    //FileHandler
    private FileHandler filehandler;
    
    public TabLecturas()
    {
        
        super();
        margin = new Insets(20,20,20,20);
        labelMargin = new Insets(20,0,20,20);
        
        //Field 1
        field1Layout1 = new HBox();
        text1 = new Text("Libro favorito: ");
        textfield1 = new TextField();
        field1Layout1.getChildren().addAll(text1, textfield1);
        HBox.setMargin(text1,labelMargin);
        HBox.setMargin(textfield1,margin);
        
        field1Layout2 = new HBox();
        text2 = new Text("Generos literarios favoritos: ");
        choicebox1 = new ChoiceBox();
        choicebox1.getItems().addAll("Fantasia","Historia","Psicologia","Autoayuda","Comedia","Ciencia Ficción","Steampunk","Terror","Cocina");
        choicebox1.setValue("Fantasia");
        text3 = new Text("Y");
        choicebox2 = new ChoiceBox();
        choicebox2.getItems().addAll("Fantasia","Historia","Psicologia","Autoayuda","Comedia","Ciencia Ficción","Steampunk","Terror","Cocina");
        choicebox2.setValue("Historia");
        field1Layout2.getChildren().addAll(text2,choicebox1,text3,choicebox2);
        
        HBox.setMargin(text2,labelMargin);
        HBox.setMargin(choicebox1,margin);
        HBox.setMargin(choicebox2,margin);
        

        field1Layout3 = new HBox();
        text4 = new Text("Escritor favorito: ");
        togglegroup1 = new ToggleGroup();
        radio1 = new RadioButton("Julio Verne");
        radio1.setToggleGroup(togglegroup1);
        radio2 = new RadioButton("Hemingway");
        radio2.setToggleGroup(togglegroup1);
        radio3 = new RadioButton("Isaac Asimov");
        radio3.setToggleGroup(togglegroup1);
        radio4 = new RadioButton("J.K. Rowling");
        radio4.setToggleGroup(togglegroup1);
        radio1.setSelected(true);
        field1Layout3.getChildren().addAll(text4,radio1,radio2,radio3,radio4);
        HBox.setMargin(text4,labelMargin);
        HBox.setMargin(radio1,margin);
        HBox.setMargin(radio2,margin);
        HBox.setMargin(radio3,margin);
        HBox.setMargin(radio4,margin);
        
        
        separator1 = new Separator();
        
        //Field 2
        field2Layout1 = new HBox();
        toggle1 = new CheckBox();
        text5 = new Text("¿Estas leyendo algun libro?");
        field2Layout1.getChildren().addAll(toggle1,text5);
        HBox.setMargin(toggle1,labelMargin);
        HBox.setMargin(text5,margin);
        
        
        field2Layout2 = new HBox();
        text6 = new Text("¿Cuanto lees semanalmante?");
        choicebox3 = new ChoiceBox();
        choicebox3.getItems().addAll("Nada","Menos de 100 paginas","Menos de 300 paginas","Menos de 500 paginas","Mas de 500 paginas");
        choicebox3.setValue("Nada");
        field2Layout2.getChildren().addAll(text6,choicebox3);
        HBox.setMargin(text6, labelMargin);
        HBox.setMargin(choicebox3, margin);
        VBox.setMargin(field2Layout1, margin);
        VBox.setMargin(field2Layout2, margin);
        separator2 = new Separator();
        
        //Field 3
        field3Layout1 = new HBox();
        field3Layout2 = new HBox();
        field3Layout3 = new HBox();
        field3Layout4 = new HBox();
        field3Layout5 = new HBox();
        
        text7 = new Text("Marque su agrado hacia :");
        text8 = new Text("Cuentos: \n");
        text9 = new Text("Fabulas: \n");
        text10 = new Text("Novelas: \n");
        text11 = new Text("0\n");
        text12 = new Text("0\n");
        text13 = new Text("0\n");
        
        slider1 = new Slider(0.00,10.00,0.00);
        slider1.setShowTickLabels(true);
        
        slider1.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> 
        {
            long valor = Math.round(new_val.doubleValue());
            slider1.setValue(valor);
            text11.setText(String.valueOf(valor) + "\n");
        });
        
        slider2 = new Slider(0.00,10.00,0.00);
        slider2.setShowTickLabels(true);
        slider2.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> 
        {
            long valor = Math.round(new_val.doubleValue());
            slider2.setValue(valor);
            text12.setText(String.valueOf(valor) + "\n");
        });
        
        
        slider3 = new Slider(0.00,10.00,0.00);
        slider3.setShowTickLabels(true);
        slider3.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> 
        {
            long valor = Math.round(new_val.doubleValue());
            slider3.setValue(valor);
            text13.setText(String.valueOf(valor) + "\n");
        });
        
        field3Layout1.getChildren().add(text7);
        HBox.setMargin(text7, labelMargin);
        
        
        field3Layout2.getChildren().addAll(text8,slider1,text11);
        HBox.setMargin(text8, labelMargin);
        HBox.setMargin(slider1, margin);
        HBox.setMargin(text11, margin);
        
        field3Layout3.getChildren().addAll(text9,slider2,text12);
        HBox.setMargin(text9, labelMargin);
        HBox.setMargin(slider2, margin);
        HBox.setMargin(text12, margin);
        
        field3Layout4.getChildren().addAll(text10,slider3,text13);
        HBox.setMargin(text10, labelMargin);
        HBox.setMargin(slider3, margin);
        HBox.setMargin(text13, margin);
        
        text14  = new Text("");
        
        submit = new Button("Finalizar Encuesta");
        submit.setOnMouseClicked(e -> {
            filehandler = new FileHandler("TabLecturas",toString(),text14);
        });
        field3Layout5.getChildren().addAll(text14,submit);
        HBox.setMargin(text14, margin);
        HBox.setMargin(submit, margin);
        
        masterLayout1 = new VBox();
        masterLayout1.getChildren().addAll(field1Layout1,field1Layout2,field1Layout3);
        
        masterLayout2 = new VBox();
        masterLayout2.getChildren().addAll(field2Layout1,field2Layout2);
        
        masterLayout3 = new VBox();
        masterLayout3.getChildren().addAll(field3Layout1,field3Layout2,field3Layout3,field3Layout4,field3Layout5);
        masterLayout3.getStyleClass().add("Tab_Lecturas");
        masterLayout3.setMinHeight(430.00);
        
        this.getChildren().addAll(masterLayout1,separator1,masterLayout2,separator2,masterLayout3);
    }
    public String getSelectedRadio() 
    {
        RadioButton temporal = (RadioButton)togglegroup1.getSelectedToggle();
            return temporal.getText();
    }
    
    @Override
    public String toString()
    {
        return String.format(textfield1.getText() + ";" + choicebox1.getValue() + ";" + choicebox2.getValue() + ";" + getSelectedRadio() + ";" + toggle1.isSelected() + ";" + choicebox3.getValue() + ";%.0f;%.0f;%.0f;\n",slider1.getValue(),slider2.getValue(),slider3.getValue());
    }
}
