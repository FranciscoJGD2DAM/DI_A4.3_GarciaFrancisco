/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appsondeos;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/**
 *
 * @author jose
 */
public class TabDeportes extends VBox {
    
    // Atributos
    Label lbNombre, lbEdad, lbBros, lbSexo, lbIconoSexo, lbDeporte, lbGrados, lbHoras, lbHorasVal, lbDinero, lbDineroVal, lbComida, lbComidaVal;
    Text confirmacion;
    TextField tfNombre;
    ChoiceBox cbEdad, cbBros, cbDeporte;
    CheckBox ckbHaceDeporte;
    RadioButton rbHombre, rbMujer;
    Slider slHoras, slDinero, slComida;
    Button btnSubmit;
    
    // Instanciamos las imagenes que ira en la etiqueta simbolizando el sexo
    Image iconSexoH = new Image("/resources/images/hombre.png", 50, 50, true, false);
    Image iconSexoM = new Image("/resources/images/mujer.png", 27, 27, true, false);
    
    // Grupo para los Radio Button
    ToggleGroup tgSexo;
    
    // Containers de secciones
    VBox sect1, sect2, sect3;
    // Container de subsecciones
    HBox cNombre, cEdadBros, cSexo, cHaceDeporte, cDeporte, cLbGrados, cHoras, cDinero, cComida, btn;
    
    
    public TabDeportes()
    {
        // Alineamos todo al centro
        this.setAlignment(Pos.CENTER);
        // Le damos distancia entre las celdas Horizontal y verticalmente
        //this.setHgap(5);
        //this.setVgap(20);
        // Le damos un margen, aunque ponga padding, es insets, por lo tanto es margen por fuera del objeto, no por dentro como un padding normal
        this.setPadding(new Insets(30));
        // Le damos visibilidad a las lineas del grid para controlar los tamaños y posiciones que van tomando, despues se quedará como comentario
        //setGridLinesVisible(true);
        // Le asignamos el espacio que habrá entre los objetos en la vista vertical
        this.setSpacing(30);
        
        // Seccion 1. Nombre, edad, hermanos, sexo
        createSect1();
        
        // Seccion 2. Deportes practicados, frecuencia, solo o acompañado
        createSect2();
        
        // Seccion 3. Sliders, boton, etiqueta envio
        createSect3();
        // Creamos ID para el sect3 que ira con imagen de fondo
        sect3.setId("DepSect3");
    
        //Añadimos las secciones a la ventana con separadores entre cada seccion
        this.getChildren().addAll(sect1, new Separator(), sect2, new Separator(), sect3);
    }
    
    // Metodo para crear la seccion 1. Nombre, edad, nº hermanos, sexo.
    private void createSect1()
    {
        // Instanciamos el contenedor de la seccion, sect1
        sect1 = new VBox();
        
        /* -------------------
           Seccion 1.1. Nombre
           ------------------- */
        // Instanciamos el contenedor
        cNombre = new HBox();
        // Alineamos el contenedor (y sus componentes) al centro
        cNombre.setAlignment(Pos.CENTER);
        // Creamos la etiqueta para pedir el nombre
        lbNombre = new Label("Nombre");
        // Creamos el campo de texto para introducir el nombre
        tfNombre = new TextField("");
        
        // Le damos espacio entre los componentes
        cNombre.setSpacing(10);
        // Añadimos ambos componentes al contenedor
        cNombre.getChildren().addAll(lbNombre, tfNombre);
        
        
        /* --------------------------------------
           Seccion 1.2. Edad y numero de hermanos
           -------------------------------------- */
        // Instanciamos el contendor
        cEdadBros = new HBox();
        // Alinemos el contenedor (y sus componentes) al centro
        cEdadBros.setAlignment(Pos.CENTER);
        
        /* Edad */
        // Creamos label para pedir la edad
        lbEdad = new Label("Edad: ");
        // Creamos el desplegable para seleccionar la edad
        cbEdad = new ChoiceBox();
        // Añadimos las posibles opciones al choicebox
        cbEdad.getItems().addAll("", "Menos de 15", "Entre 15 y 18", "Entre 19 y 35", "Entre 36 y 60", "Mas de 60");
        // Establecemos valor por defecto
        cbEdad.setValue("");
        /* Hermanos */
        // Creamos label para pedir hermanos
        lbBros = new Label("Nº de hermanos: ");
        // Creamos el desplegable para seleccionar el numero de hermanos
        cbBros = new ChoiceBox();
        // Añadimos las posibles opciones al choicebox
        cbBros.getItems().addAll("", "Ninguno", "Uno", "Dos", "Mas de dos");
        // Establecemos valor por defecto
        cbBros.setValue("");
        
        // Añadimos los cuatro componentes al HBox de la segunda seccion
        cEdadBros.getChildren().add(lbEdad);
        cEdadBros.getChildren().add(cbEdad);
        // Mayor separacion entre los dos grupos de componentes
        cEdadBros.getChildren().add(new Label("\t"));
        cEdadBros.getChildren().add(lbBros);
        cEdadBros.getChildren().add(cbBros);
        
        /* -----------------
           Seccion 1.3. Sexo
           ----------------- */
        // Instamciamos el contenedor
        cSexo = new HBox();
        // Alinemos el contendor (y sus componentes) al centro
        cSexo.setAlignment(Pos.CENTER);
        
        // Creamos etiqueta para pedir sexo
        lbSexo = new Label("Sexo: ");
        // Creamos un ToggleGroup para que al seleccionar una opcion se desmarque la otra
        ToggleGroup rbSexo = new ToggleGroup();
        // Creamos el radiobutton para el hombre
        rbHombre = new RadioButton("Hombre");
        // Añadimos clase para el estilo
        rbHombre.getStyleClass().add("RadioButtons");
        // Lo marcamos po defecto
        rbHombre.setSelected(true);
        // Lo añadimos al grupo
        rbHombre.setToggleGroup(rbSexo);
        // Creamos el rb para la opcion mujer
        rbMujer = new RadioButton("Mujer");
        // Añadimos clase para el estilo
        rbMujer.getStyleClass().add("RadioButtons");
        // Añadimos la opcion al grupo
        rbMujer.setToggleGroup(rbSexo);
        
        // Creamos la etiqueta que contendra el icono
        lbIconoSexo = new Label();
        // Establecemos la imagen por defecto
        lbIconoSexo.setGraphic(new ImageView(iconSexoH));
        // Añadimos listener con funcion lambda para que la etiqueta cambie segun el sexo elegido
        rbSexo.selectedToggleProperty().addListener(e -> {
            
            if(rbHombre.isSelected())
            {
                lbIconoSexo.setGraphic(new ImageView(iconSexoH));
            }
            else
            {
                lbIconoSexo.setGraphic(new ImageView(iconSexoM));
            }
        });
        
        // Le asignamos un espacio entre los componentes
        cSexo.setSpacing(20);
        // Añadimos los componentes al contendor
        cSexo.getChildren().addAll(lbSexo, rbHombre, rbMujer, lbIconoSexo);
        
        
        /* Añadimos todos los contenedores al contendor de la seccion 1 */
        // establecemos separacion para todos los componentes
        sect1.setSpacing(35);
        // Añadimos los componentes
        sect1.getChildren().addAll(cNombre, cEdadBros, cSexo);
    }
    
    private void createSect2()
    {
        // Instanciamos el contenedor de la seccion 2
        sect2 = new VBox();
        
        /* --------------------------------
           Seccion 2.1. CheckBox deportista
           -------------------------------- */
        // Instanciamos el contenedor donde ira el checkbox
        cHaceDeporte = new HBox();
        // Creamos el checkbox
        ckbHaceDeporte = new CheckBox("¿Practicas algún deporte?");
        // añadimos el componente al contenedor
        cHaceDeporte.getChildren().add(ckbHaceDeporte);
        
        /* --------------------------------
           Seccion 2.1. ChoiceBox deporte
           -------------------------------- */
        // Instanciamos el contenedor donde iran los componentes
        cDeporte = new HBox();
        // Establecemos la alineacion de los componentes
        cDeporte.setAlignment(Pos.CENTER);
        // Creamos la etiqueta con la pregunta
        lbDeporte = new Label("¿Qué deporte practicas?: ");
        // Creamos el desplegable para elegir deporte
        cbDeporte = new ChoiceBox();
        // Añadimos los posibles valores
        cbDeporte.getItems().addAll("", "Natacion", "Futbol", "Baloncesto", "Tenis", "Ciclismo", "Balonmano", "Badminton");
        // Establecemos valor por defecto
        cbDeporte.setValue("");
        
        
        // Damos separacion entre ambos componentes
        cDeporte.setSpacing(15);
        // Incluimos los elementos
        cDeporte.getChildren().addAll(lbDeporte, cbDeporte);
        
        // Damos separacion entre los componentes al contenedor de la seccion
        sect2.setSpacing(40);
        // Añadimos los contenedores a la seccion
        sect2.getChildren().addAll(cHaceDeporte, cDeporte);
        // Le damos padding a la seccion 2 para que se separe por abajo del separador
        sect2.setPadding(new Insets(5, 5, 70, 5));
    }
    
    private void createSect3()
    {
        // Instanciamos el contenedor de la seccion 3
        sect3 = new VBox();
        // Le asignamos el espaciado que habra entre los componentes
        sect3.setSpacing(20);
        
        /* ----------------------------
           Seccion 3.1. Etiqueta grados
           ---------------------------- */
        // Instanciamos el contenedor
        cLbGrados = new HBox();
        // Establecemos la alineacion de los componentes
        cLbGrados.setAlignment(Pos.CENTER);
        // Ceamos la etiqueta
        lbGrados = new Label("Indica, en relacion al deporte:");
        
        // Añadimos la etiqueta al contenedor
        cLbGrados.getChildren().add(lbGrados);
        
        
        /* ----------------------------
           Seccion 3.2. Slider Horas
           ---------------------------- */
        // Instanciamos el contenedor
        cHoras = new HBox();
        // Alinemos componetnes
        cHoras.setAlignment(Pos.CENTER);
        // Establecemos el espacio entre componentes
        cHoras.setSpacing(15);
        
        // Creamos la etiqueta
        lbHoras = new Label("Nº Horas / semana");
        // Creamos el slider
        slHoras = new Slider(0, 10, 5);
        // Hacemos visibles las marcas
        slHoras.setShowTickLabels(true);
        // Etablecemos la distancia entre etiquetas
        slHoras.setMajorTickUnit(1);
        // Le decimos el incremento que debe hacer, 1 unidad
        slHoras.setBlockIncrement(1.0f);
        // Ponemos a true la propiedad que hace que el cursor se mueva hacia el tick mas proximo
        slHoras.setSnapToTicks(true);
        // Le asignamos un tamaño al slider
        slHoras.setPrefWidth(300);
        
        // Label para mostrar valor del slider
        lbHorasVal = new Label("");
        
        // Listener que escucha los cambio del slider y..
        slHoras.valueProperty().addListener(new ChangeListener<Number>() {
            
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) 
            {
                // ... hace que el valor del slider vaya de unidad en unidad...
                long num = Math.round(new_val.doubleValue());
                slHoras.setValue(num);
                
                //... Asignamos dicho valor a la etiqueta que expresa el valor del slider
                lbHorasVal.setText(String.valueOf(num));
            }
            
        });
        
        // Añadimos todos los componentes al contenedor del slider de las horas
        cHoras.getChildren().addAll(lbHoras, slHoras, lbHorasVal);
        
        
        /* ----------------------------
           Seccion 3.3. Slider Dinero
           ---------------------------- */
        // Instanciamos el contenedor
        cDinero = new HBox();
        // Alinemos componetnes
        cDinero.setAlignment(Pos.CENTER);
        // Establecemos el espacio entre componentes
        cDinero.setSpacing(15);
        
        // Creamos la etiqueta
        lbDinero = new Label("Dinero gastado");
        // Creamos el slider
        slDinero = new Slider(0, 10, 5);
        // Hacemos visibles las marcas
        slDinero.setShowTickLabels(true);
        // Etablecemos la distancia entre etiquetas
        slDinero.setMajorTickUnit(1);
        // Le decimos el incremento que debe hacer, 1 unidad
        slDinero.setBlockIncrement(1.0f);
        // Ponemos a true la propiedad que hace que el cursor se mueva hacia el tick mas proximo
        slDinero.setSnapToTicks(true);
        // Le asignamos un tamaño al slider
        slDinero.setPrefWidth(300);
        
        // Label para mostrar valor del slider
        lbDineroVal = new Label("");
        
        // Listener que escucha los cambio del slider y..
        slDinero.valueProperty().addListener(new ChangeListener<Number>() {
            
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) 
            {
                // ... hace que el valor del slider vaya de unidad en unidad...
                long num = Math.round(new_val.doubleValue());
                slDinero.setValue(num);
                
                //... Asignamos dicho valor a la etiqueta que expresa el valor del slider
                lbDineroVal.setText(String.valueOf(num));
            }
            
        });
        
        // Añadimos todos los componentes
        cDinero.getChildren().addAll(lbDinero, slDinero, lbDineroVal);
        
        
        /* ----------------------------
           Seccion 3.4. Slider Comida
           ---------------------------- */
        // Instanciamos el contenedor
        cComida = new HBox();
        // Alinemos componetnes
        cComida.setAlignment(Pos.CENTER);
        // Establecemos el espacio entre componentes
        cComida.setSpacing(15);
        
        // Creamos la etiqueta
        lbComida = new Label("Controlar alimentacion");
        // Creamos el slider
        slComida = new Slider(0, 10, 5);
        // Hacemos visibles las marcas
        slComida.setShowTickLabels(true);
        // Etablecemos la distancia entre etiquetas
        slComida.setMajorTickUnit(1);
        // Le decimos el incremento que debe hacer, 1 unidad
        slComida.setBlockIncrement(1.0f);
        // Ponemos a true la propiedad que hace que el cursor se mueva hacia el tick mas proximo
        slComida.setSnapToTicks(true);
        // Le asignamos un tamaño al slider
        slComida.setPrefWidth(300);
        
        // Label para mostrar valor del slider
        lbComidaVal = new Label("");
        
        // Listener que escucha los cambio del slider y..
        slComida.valueProperty().addListener(new ChangeListener<Number>() {
            
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) 
            {
                // ... hace que el valor del slider vaya de unidad en unidad...
                long num = Math.round(new_val.doubleValue());
                slComida.setValue(num);
                
                //... Asignamos dicho valor a la etiqueta que expresa el valor del slider
                lbComidaVal.setText(String.valueOf(num));
            }
            
        });
        
        // Añadimos los componentes
        cComida.getChildren().addAll(lbComida, slComida, lbComidaVal);
        
        
        /* ----------------------------
           Seccion 3.5. Etiqueta y boton
           ---------------------------- */
        // Instanciamos el contenedor 
        btn = new HBox();
        // Alineamos componentes
        btn.setAlignment(Pos.BASELINE_RIGHT);
        // Establecemos espacio entre componentes
        btn.setSpacing(40);
        
        // Creamos campo de texto para confirmar que se han guardado los datos
        confirmacion = new Text("");
        // Creamos el boton
        btnSubmit = new Button("Submit");
        
        
        // Añadimos listener con la accion a realizar por el boton
        btnSubmit.setOnAction(e ->{
            FileHandler filehandler = new FileHandler("TabDeportes", this.toString(), confirmacion);
        });
        
        // Añadimos los componentes al contendor
        btn.getChildren().addAll(confirmacion, btnSubmit);
        
        
        // Añadimos los contenedores a la seccion
        sect3.getChildren().addAll(cLbGrados, cHoras, cDinero, cComida);
        
        // Le damos mas distancia al boton
        sect3.setSpacing(35);
        // Añadimos el boton y la etiqueta
        sect3.getChildren().add(btn);
        
    }
    
    @Override
    public String toString()
    {
        return tfNombre.getText() + ";" + cbEdad.getValue() +";" + cbBros.getValue() + ";" + 
                ((rbHombre.isSelected()?"Hombre":"Mujer")) + ";" + (ckbHaceDeporte.isSelected()?"Si":"No") + 
                ";" + cbDeporte.getValue() + ";" + String.valueOf(slHoras.getValue()) + ";" + String.valueOf(slDinero.getValue()) + ";" + 
                String.valueOf(slComida.getValue()) + ";\n";
    }
}
