/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appsondeos;



import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;


public class TabComidas extends VBox{
  
    //public static final double TAMLETRA = 18;
    //private final Font tamaño = new Font(18);
    private final ToggleGroup sexo;
    private final TextField text1;
    private final ChoiceBox año;
    private final ChoiceBox numHermanos;
    private final ChoiceBox veces;
    private final CheckBox selecionar;
    private final Slider slider1;  
    private final Slider slider2;
    private final Slider slider3;
    
    public TabComidas()
    {
        GridPane root = new GridPane();
        

        HBox conten1 = new HBox();
        conten1.setPrefWidth(400);
        
        HBox conten2 = new HBox();
        conten1.setAlignment(Pos.CENTER);
        conten2.setAlignment(Pos.CENTER);
        
        HBox conten3 = new HBox();
        conten3.setAlignment(Pos.CENTER);
        
        HBox conten4 = new HBox();
        conten4.setAlignment(Pos.CENTER);
        
        HBox conten5 = new HBox();
        conten5.setAlignment(Pos.CENTER);
        
        HBox conten6 = new HBox();
        conten6.setAlignment(Pos.CENTER);
        
        HBox conten7 = new HBox();
        conten7.setAlignment(Pos.CENTER_RIGHT);
        
        VBox seccion3Comidas = new VBox();
        
        
        root.setGridLinesVisible(false);
        
        root.setAlignment(Pos.CENTER);
        root.setHgap(20);
        root.setVgap(20);
        
        root.setPadding(new Insets(30));
        
    
        
        Label label1 = new Label("Profesion: ");
        text1 = new TextField();
        
        
        
        //root1.getChildren().addAll(label1,text1);
        //root.add(label1, 0, 0);
        //root.add(text1, 1 ,0);
        
        Label label2 = new Label("Edad: ");
        
        año = new ChoiceBox();
        año.getItems().addAll("entre 12 y 18","entre 18 y 25","entre 25 y 40","entre 40 y 55","entre 55 y 70","entre 70 y mas");
        
        
        Label label3 = new Label("Nº Hermanos: ");
    
        numHermanos = new ChoiceBox();
        numHermanos.getItems().addAll("ninguno","uno","dos","tres","cuatro","mas de cinco");
        
        
        root.add(label1, 0, 0);
        root.add(text1, 1 ,0);
        root.add(label2, 0, 1);
        root.add(año, 1 ,1);
        root.add(label3, 2, 1);
        root.add(numHermanos, 3 ,1);
        
      
        
        RadioButton hombre = new RadioButton("Hombre");
        hombre.getStyleClass().add("RadioButtons");
        hombre.setSelected(true);
        
        RadioButton mujer = new RadioButton("Mujer");
        mujer.getStyleClass().add("RadioButtons");
   
        
        sexo = new ToggleGroup();
        
        hombre.setToggleGroup(sexo);
        mujer.setToggleGroup(sexo);
       
        
        Label selecImagen = new Label();
        
        sexo.selectedToggleProperty().addListener( e -> {
            
        if(hombre.isSelected()){
            Image imagen = new Image("/resources/images/SimHombre.png",50,40,true,false);

            selecImagen.setGraphic(new ImageView(imagen));
        
        }else if (mujer.isSelected()){
            
            Image imagen = new Image("/resources/images/SimMujer.png",50,40,true,false);
        
            selecImagen.setGraphic(new ImageView(imagen));
        }
        
            
        });
        Image imagen = new Image("/resources/images/SimHombre.png",50,40,true,false);

        selecImagen.setGraphic(new ImageView(imagen));
       
        
        
        
        
        conten1.getChildren().addAll(hombre,mujer,selecImagen);
        conten1.setSpacing(50);
        
        
        
        Separator separador1 = new Separator();
        separador1.setPadding(new Insets(20, 10, 10, 10));
        
        selecionar = new CheckBox("¿Cocinas habitualmente?");
        selecionar.setPadding(new Insets(20, 10, 80, 40));
        
        Label label4 = new Label("Cuantas veces al dia: ");
        
        veces = new ChoiceBox();
        veces.getItems().addAll("una vez","dos veces","tres veces","cuatro veces","mas de cuatro");
        
        conten2.getChildren().addAll(label4,veces);
        conten2.setSpacing(50);
        
        Separator separador2 = new Separator();
        separador2.setPadding(new Insets(40, 10, 0, 10));
        
        Label label5 = new Label("Marque del 1 al 10 la valoracion del tipo de comida:");
        //label5.setAlignment(Pos.CENTER);
        conten3.getChildren().add(label5);
        conten3.setPadding(new Insets(40, 0, 20, 0));
        
        
        Label label6 = new Label("Vegetariana: ");
        
        slider1 = new Slider(0, 10, 0);
        slider1.setShowTickMarks(true);
        slider1.setShowTickLabels(true);
        slider1.setMajorTickUnit(1f);
        slider1.setBlockIncrement(0.1f);
        
        slider1.setPrefWidth(250);
       
        
        Label numeroCam = new Label("0");
        
        label6.setPadding(new Insets(0, 30, 15, 0));
        numeroCam.setPadding(new Insets(0, 30, 15, 40));
        
        slider1.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider1.setValue(valor);
            numeroCam.setText(String.valueOf(valor)+ "\n");
        });
        
        
        
        conten4.getChildren().addAll(label6,slider1,numeroCam);
        
        
        conten4.setPadding(new Insets(20, 10, 20, 10));
        
        
        Label label7 = new Label("Mediterranea: ");
        
        slider2 = new Slider(0, 10, 0);
        slider2.setShowTickMarks(true);
        slider2.setShowTickLabels(true);
        slider2.setMajorTickUnit(1f);
        slider2.setBlockIncrement(0.1f);
        
        slider2.setPrefWidth(250);
        
        Label numeroCam2 = new Label("0");
        
        label7.setPadding(new Insets(0, 30, 15, 0));
        numeroCam2.setPadding(new Insets(0, 30, 15, 40)); 
        
        slider2.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider2.setValue(valor);
            numeroCam2.setText(String.valueOf(valor)+ "\n");
        });
    
        conten5.getChildren().addAll(label7,slider2,numeroCam2);
        
        conten5.setPadding(new Insets(20, 10, 20, 10));
        
        Label label8 = new Label("Comida Rapida: ");
        
        slider3 = new Slider(0, 10, 0);
        slider3.setShowTickMarks(true);
        slider3.setShowTickLabels(true);
        slider3.setMajorTickUnit(1f);
        slider3.setBlockIncrement(0.1f);
        
        slider3.setPrefWidth(250);
        
        Label numeroCam3 = new Label("0");
        
        label8.setPadding(new Insets(0, 30, 15, 0));
        numeroCam3.setPadding(new Insets(0, 30, 15, 40));
        
        slider3.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            long valor = Math.round(new_val.doubleValue());
            slider3.setValue(valor);
            numeroCam3.setText(String.valueOf(valor)+ "\n");
        });
        numeroCam3.getText();
        
        conten6.getChildren().addAll(label8,slider3,numeroCam3);
        
        conten6.setPadding(new Insets(20, 10, 20, 10));
        
        Button enviar = new Button("Enviar");
         
        Text tester  = new Text("");
        
        
        enviar.setOnMouseClicked(e -> {
            FileHandler  filehandler = new FileHandler("TabComidas",toString(),tester);
        });
        
        conten7.getChildren().addAll(tester,enviar);
        
 
        
        conten7.setPadding(new Insets(10, 40, 20, 10));
        
        
        seccion3Comidas.getChildren().addAll(conten3,conten4,conten5,conten6,conten7);
        seccion3Comidas.getStyleClass().add("seccion3Comidas");
        seccion3Comidas.setMinHeight(430.00);
      
        
        getChildren().addAll(root,conten1,separador1,selecionar,conten2,separador2,seccion3Comidas);
        
    }
     public String getSelectedRadio() 
    {
        RadioButton temporal = (RadioButton)sexo.getSelectedToggle();
            return temporal.getText();
    }
      @Override
    public String toString()
    {
        return String.format(text1.getText() + ";" + año.getValue() + ";" + numHermanos.getValue() + ";" + getSelectedRadio() + ";" + selecionar.isSelected() + ";" + veces.getValue() + ";%.2f;%.2f;%.2f;\n",slider1.getValue(),slider2.getValue(),slider3.getValue());
    }
}
